const Navbar=()=>{
    return (
        <header>
        <nav>
            <ol>
            <li>Home</li>
            <li>About</li>
            <li>Gallery</li>
            <li>Contact</li>
            </ol>
        </nav>
        </header>
    );
}

export default Navbar;