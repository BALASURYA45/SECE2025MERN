import React from "react";
class ClassCompEG extends React.Component{
    render(){
        return(
            <div>
                <h3>This is a class Component Example.</h3>
            </div>
        )
    }
}
export default ClassCompEG;